/*
 * $Id: HelloWorld.java 5394 2006-04-16 13:36:52 +0000 (Sun, 16 Apr 2006)
 * jdonnerstag $ $Revision: 1.3 $ $Date: 2006-04-16 13:36:52 +0000 (Sun, 16 Apr
 * 2006) $
 * 
 * ==================================================================== Licensed
 * under the Apache License, Version 2.0 (the "License"); you may not use this
 * file except in compliance with the License. You may obtain a copy of the
 * License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package wicket.in.action.chapter10.jcaptcha;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.rmi.server.UID;

import wicket.MarkupContainer;
import wicket.Session;
import wicket.markup.ComponentTag;
import wicket.markup.html.WebPage;
import wicket.markup.html.form.Form;
import wicket.markup.html.form.RequiredTextField;
import wicket.markup.html.image.Image;
import wicket.markup.html.image.resource.DynamicImageResource;
import wicket.markup.html.panel.FeedbackPanel;
import wicket.model.IModel;
import wicket.model.PropertyModel;
import wicket.validation.IValidatable;
import wicket.validation.validator.AbstractValidator;

import com.octo.captcha.service.image.DefaultManageableImageCaptchaService;
import com.octo.captcha.service.image.ImageCaptchaService;
import com.sun.image.codec.jpeg.JPEGCodec;
import com.sun.image.codec.jpeg.JPEGImageEncoder;

public class JCaptcha extends WebPage {

  private static final class CaptchaForm extends Form {

    private String challengeId = null;

    private String challengeResponse;

    public CaptchaForm(MarkupContainer parent, String id) {
      super(parent, id);

      DynamicImageResource captchaImageResource = new DynamicImageResource() {
        protected byte[] getImageData() {
          try {
            ByteArrayOutputStream jpegOutputStream = new ByteArrayOutputStream();
            challengeId = new UID().toString();
            BufferedImage challenge = captchaService
                .getImageChallengeForID(challengeId, Session.get()
                    .getLocale());
            JPEGImageEncoder jpegEncoder = JPEGCodec
                .createJPEGEncoder(jpegOutputStream);
            jpegEncoder.encode(challenge);
            return jpegOutputStream.toByteArray();
          } catch (Exception e) {
            throw new RuntimeException(e);
          }
        }
      };
      new Image(this, "captchaImage", captchaImageResource);

      IModel<String> responseModel = new PropertyModel<String>(this,
          "challengeResponse");
      final RequiredTextField responseField = new RequiredTextField<String>(
          this, "response", responseModel) {
        protected final void onComponentTag(final ComponentTag tag) {
          super.onComponentTag(tag);
          tag.put("value", "");
        }
      };

      responseField.add(new AbstractValidator<String>() {

        protected void onValidate(IValidatable<String> validatable) {
          if (!captchaService.validateResponseForID(challengeId,
              validatable.getValue())) {
            error(validatable);
          }
        }

        @Override
        protected String resourceKey() {
          return "captcha.validation.failed";
        }
      });

      new FeedbackPanel(this, "feedback");
    }

    public String getChallengeResponse() {
      return challengeResponse;
    }

    public void setChallengeResponse(String challengeResponse) {
      this.challengeResponse = challengeResponse;
    }

    protected void onSubmit() {
      info(getLocalizer().getString("captcha.validation.succeeded",
          this));
    }
  }

  private static final ImageCaptchaService captchaService = new DefaultManageableImageCaptchaService();

  public JCaptcha() {
    new CaptchaForm(this, "form");
  }
}